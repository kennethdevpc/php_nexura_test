-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 18-05-2023 a las 18:53:07
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistemaempleado`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `areas`
--

CREATE TABLE `areas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `areas`
--

INSERT INTO `areas` (`id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Administrativa y Financiera', NULL, NULL),
(2, 'Ingeniería', NULL, NULL),
(3, 'Desarrollo de Negocio', NULL, NULL),
(4, 'Proyectos', NULL, NULL),
(5, 'Servicios', NULL, NULL),
(6, 'Calidad', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cars`
--

CREATE TABLE `cars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boletin` int(11) DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `area_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `nombre`, `email`, `sexo`, `boletin`, `descripcion`, `created_at`, `updated_at`, `area_id`) VALUES
(1, 'Pedro Pérez', 'perez@example.co', 'M', 1, 'pedro perez, es un excelente empleado por su gran energia en cada laborssssssss text area okey', NULL, '2023-05-18 20:28:30', 1),
(2, 'Amalia Bayona', 'abayona@example.co', 'M', 1, 'Para contactar a Amalia Bayona, puede escribir al correo electrónico abayona@example.co', NULL, '2023-05-18 02:53:18', 1),
(3, 'lionel', 'lionel@gmail.com', 'M', 0, 'no hay en cuanto se puede', NULL, '2023-05-18 02:44:18', 2),
(4, 'will', 'apellidod@gmail.com', 'M', 1, 's', NULL, NULL, 1),
(6, 'martin', 'ingkeneidel@gmail.com', 'F', 1, 'no hay descripcion', NULL, NULL, 1),
(7, 'maricha', 'maricha@hmail.com', 'F', 1, 'ella  se llama marichelw', NULL, NULL, 2),
(8, '0000-0002-5425-8950', 'apellidod@gmail.com', 'F', 1, 'sss', NULL, NULL, 2),
(9, '0000-0002-5374-9993', 'ingkeneidel@gmail.com', 'F', 1, 'sss', NULL, NULL, 2),
(10, 'niño', 'ingkeneidel@gmail.com', 'F', 1, 'sss', NULL, NULL, 2),
(11, 'niño', 'ingkeneidel@gmail.com', 'F', 1, 'sss', NULL, NULL, 2),
(12, 'niño', 'ingkeneidel@gmail.com', 'F', 1, 'sss', NULL, NULL, 2),
(13, 'niño', 'ingkeneidel@gmail.com', 'F', 1, 'sss', '2023-05-18 21:05:31', '2023-05-18 21:05:31', NULL),
(14, 'kenneth niño', 'ken_puli95@hotmail.com', 'F', 1, 'kennethniño es uno de los mejores', '2023-05-18 21:06:08', '2023-05-18 21:06:08', NULL),
(15, 'kenneth seta', 'ken_puli95@hotmail.com', 'F', 1, 'kennethniño es uno de los mejores', '2023-05-18 21:06:55', '2023-05-18 21:06:55', NULL),
(16, 'alexis', 'alexis@hotmail.com', 'M', 1, 'alexis es uno de los mejores', '2023-05-18 21:08:02', '2023-05-18 21:08:02', NULL),
(17, 'alexis', 'alexis@hotmail.com', 'M', 1, 'alexis es uno de los mejores', '2023-05-18 21:11:32', '2023-05-18 21:11:32', NULL),
(18, 'alexis', 'alexis@hotmail.com', 'M', 1, 'alexis es uno de los mejores', '2023-05-18 21:12:43', '2023-05-18 21:12:43', NULL),
(19, 'metodo2 okey', 'metodo2@hotmail.com', 'M', 1, 'alexis es uno de los mejores', '2023-05-18 21:15:07', '2023-05-18 21:15:07', NULL),
(20, 'metodo2 okey', 'metodo2@hotmail.com', 'M', 1, 'alexis es uno de los mejores', '2023-05-18 21:15:57', '2023-05-18 21:15:57', NULL),
(21, 'metodo2 okey', 'metodo2@hotmail.com', 'M', 1, 'alexis es uno de los mejores', '2023-05-18 21:16:22', '2023-05-18 21:16:22', NULL),
(22, 'kenneth', 'apellidod@gmail.com', 'M', NULL, 's', '2023-05-18 21:16:57', '2023-05-18 21:16:57', NULL),
(23, 'kenneth', 'mailharcodeeeado@gmail.com', 'M', NULL, 'ss', '2023-05-18 21:17:55', '2023-05-18 21:17:55', NULL),
(24, 'niño', 'ingkeneidel@gmail.com', 'M', 1, 'www', '2023-05-18 21:18:52', '2023-05-18 21:18:52', NULL),
(25, 'kenneth', 'apellidod@gmail.com', 'M', 1, 'qqqqqq', '2023-05-18 21:19:51', '2023-05-18 21:19:51', NULL),
(26, 'manuel kenneth', 'mailharcodeeeado@gmail.com', 'F', 1, 'wwww', '2023-05-18 21:21:08', '2023-05-18 21:21:08', 1),
(27, 'lione', 'kilo@gmail.com', 'M', 1, 'update', '2023-05-18 21:22:47', '2023-05-18 21:23:23', 1),
(28, 'nuevoois', 'nuevoois@gmail.com', 'M', 1, 'nuevoois', '2023-05-18 21:50:25', '2023-05-18 21:50:25', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_role`
--

CREATE TABLE `empleado_role` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `empleado_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `empleado_role`
--

INSERT INTO `empleado_role` (`id`, `role_id`, `empleado_id`, `created_at`, `updated_at`) VALUES
(9, 2, 1, NULL, NULL),
(10, 5, 1, NULL, NULL),
(11, 8, 1, NULL, NULL),
(12, 4, 15, NULL, NULL),
(13, 7, 15, NULL, NULL),
(14, 2, 16, NULL, NULL),
(15, 3, 16, NULL, NULL),
(16, 4, 16, NULL, NULL),
(17, 5, 16, NULL, NULL),
(18, 6, 16, NULL, NULL),
(19, 7, 16, NULL, NULL),
(20, 8, 16, NULL, NULL),
(21, 9, 16, NULL, NULL),
(22, 2, 17, NULL, NULL),
(23, 3, 17, NULL, NULL),
(24, 4, 17, NULL, NULL),
(25, 5, 17, NULL, NULL),
(26, 6, 17, NULL, NULL),
(27, 7, 17, NULL, NULL),
(28, 8, 17, NULL, NULL),
(29, 9, 17, NULL, NULL),
(30, 2, 18, NULL, NULL),
(31, 3, 18, NULL, NULL),
(32, 4, 18, NULL, NULL),
(33, 5, 18, NULL, NULL),
(34, 6, 18, NULL, NULL),
(35, 7, 18, NULL, NULL),
(36, 8, 18, NULL, NULL),
(37, 9, 18, NULL, NULL),
(38, 3, 19, NULL, NULL),
(39, 6, 19, NULL, NULL),
(40, 7, 19, NULL, NULL),
(41, 8, 19, NULL, NULL),
(42, 3, 20, NULL, NULL),
(43, 6, 20, NULL, NULL),
(44, 7, 20, NULL, NULL),
(45, 8, 20, NULL, NULL),
(46, 3, 21, NULL, NULL),
(47, 6, 21, NULL, NULL),
(48, 7, 21, NULL, NULL),
(49, 8, 21, NULL, NULL),
(50, 1, 24, NULL, NULL),
(51, 1, 25, NULL, NULL),
(52, 4, 25, NULL, NULL),
(53, 2, 26, NULL, NULL),
(54, 5, 26, NULL, NULL),
(57, 1, 28, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_05_15_140139_create_areas_table', 1),
(7, '2023_05_15_140300_create_cars_table', 1),
(8, '2023_05_16_205926_create_empleados_table', 1),
(9, '2023_05_17_155325_create_roles_table', 1),
(10, '2023_05_17_155719_create_empleado_rol_table', 1),
(11, '2023_05_17_155719_create_empleado_role_table', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`, `created_at`, `updated_at`) VALUES
(1, 'Desarrollador', NULL, NULL),
(2, 'Analista', NULL, NULL),
(3, 'tester', NULL, NULL),
(4, 'diseñador', NULL, NULL),
(5, 'profesional pmo', NULL, NULL),
(6, 'profesional de servicios', NULL, NULL),
(7, 'auxilia admin', NULL, NULL),
(8, 'codirectos', NULL, NULL),
(9, 'otrosss', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'kenneth', 'kiko@gmail.com', NULL, '$2y$10$m4gNUIp0MqepaIfyTlvCuernHDE4dHPWZNubHQgpWWUS6Kt/0aCvq', NULL, '2023-05-17 21:42:48', '2023-05-17 21:42:48'),
(2, 'kenneth', 'ingkeneidel@gmail.com', NULL, '$2y$10$0xOHXFdDX2LH.hy8gbSPY.5noCEByW/BEMf2/HnVSQkqW.1n9IGBq', NULL, '2023-05-17 23:03:51', '2023-05-17 23:03:51'),
(3, 'kenneth', 'ei@gmail.com', NULL, '$2y$10$UDFw9iHr7ORr4v0BvdQ7f.r/G1/Z8tOycISw/lGL1/M8/LBgqsVCO', NULL, '2023-05-17 23:47:59', '2023-05-17 23:47:59');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `areas`
--
ALTER TABLE `areas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empleados_area_id_foreign` (`area_id`);

--
-- Indices de la tabla `empleado_role`
--
ALTER TABLE `empleado_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `empleado_role_role_id_foreign` (`role_id`),
  ADD KEY `empleado_role_empleado_id_foreign` (`empleado_id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `areas`
--
ALTER TABLE `areas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `cars`
--
ALTER TABLE `cars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `empleado_role`
--
ALTER TABLE `empleado_role`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD CONSTRAINT `empleados_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `empleado_role`
--
ALTER TABLE `empleado_role`
  ADD CONSTRAINT `empleado_role_empleado_id_foreign` FOREIGN KEY (`empleado_id`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `empleado_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
